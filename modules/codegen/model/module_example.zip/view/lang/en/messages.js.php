<?php
/**
 * Переводы для фраз, встречающихся в JS файлах
 */
return array(
    'Фраза на Русском' => 'Phrase in English'
);
