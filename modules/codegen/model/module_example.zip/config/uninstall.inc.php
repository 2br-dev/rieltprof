<?php

namespace @NAME@\Config;

use RS\Module\AbstractUninstall;

/**
 * Класс деинсталяции модуля
 */
class Uninstall extends AbstractUninstall
{}
