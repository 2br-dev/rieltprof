<?php

namespace @NAME@\Config;

use RS\Module\AbstractInstall;

/**
 * Класс отвечает за установку и обновление модуля
 */
class Install extends AbstractInstall
{}
